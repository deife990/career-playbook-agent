import argparse,json,subprocess,sys,hashlib,fcntl
from pathlib import Path
from datetime import datetime,timezone
from scripts.run_model_evals import fingerprint,suite_fingerprint
from scripts.eval_protocol import protocol,protocol_fingerprint
ROOT=Path.cwd();BASE=ROOT/'work/review-v2/rc8-release-2026-10-17';PLAN=json.loads((ROOT/'evals/reports/rc8-release-plan-2026-10-17.json').read_text())
p=argparse.ArgumentParser();p.add_argument('--phase',choices=['quick','final'],required=True);p.add_argument('--platform',choices=['claude','chatgpt'],required=True);p.add_argument('--max-cases',type=int,default=3);a=p.parse_args()
assert a.max_cases in [1,2,3]
assert not (a.phase=='quick' and a.platform!='claude')
assert hashlib.sha256((ROOT/'docs/rc8-release-policy-2026-10-17.md').read_bytes()).hexdigest()==PLAN['policy_sha256']
assert hashlib.sha256((ROOT/'scripts/run_model_evals.py').read_bytes()).hexdigest()==PLAN['frozen_engine_sha256']
assert suite_fingerprint(sorted((ROOT/'evals/scenarios').glob('*.yaml')))==PLAN['c_suite_fingerprint']
assert fingerprint(BASE/'packages'/a.platform)==PLAN['packages'][a.platform]['package_fingerprint']
assert protocol_fingerprint(protocol())==PLAN['c_protocol_fingerprint']
reportdir=BASE/a.phase;reportdir.mkdir(exist_ok=True);reportpath=reportdir/(a.platform+'.json')
with (BASE/'.execution.lock').open('a') as guard:
 fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
 rows=json.loads(reportpath.read_text())['cases'] if reportpath.exists() else []
 if any(r['status']=='ERROR' for r in rows):sys.exit('Existing ERROR quarantined; stop for review')
 existing={(r['id'],r['run']) for r in rows if r['status'] in ['PASS','FAIL']}
 definitions=protocol(runs=1 if a.phase=='quick' else None)['scenarios'];selected=[]
 for d in definitions:
  if a.phase=='quick' and d['id'] not in PLAN['quick_scenarios']:continue
  if not all((d['id'],n) in existing for n in range(1,d['runs']+1)):selected.append(d)
 for d in selected[:a.max_cases]:
  cmd=[sys.executable,'-m','scripts.run_model_evals','--platform',a.platform,'--package-root',str(BASE/'packages'/a.platform),'--report-dir',str(reportdir),'--resume','--scenario',d['id']]
  if a.phase=='quick':cmd+=['--runs','1']
  print('START',a.phase,a.platform,d['id'],flush=True)
  result=subprocess.run(cmd,cwd=ROOT)
  report=json.loads(reportpath.read_text());new=report['cases'];snapshot=reportdir/('checkpoint-'+a.platform+'-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f')+'.json');snapshot.write_bytes(reportpath.read_bytes())
  for old in rows:assert next(r for r in new if (r['id'],r['run'])==(old['id'],old['run']))==old
  current=[r for r in new if r['id']==d['id']]
  if not current or any(r['status']=='ERROR' for r in current):sys.exit('Provider/evaluation ERROR preserved; stopping')
  for row in current:
   expected_subject='claude-sonnet-4-6' if a.platform=='claude' else 'gpt-5.6-sol'
   expected_judge='claude-sonnet-4-6' if row['judge_platform']=='claude' else 'gpt-5.6-sol'
   if set(row.get('model_ids',[]))!={expected_subject} or row.get('judge_model')!=expected_judge:sys.exit('Model identity mismatch/unavailable; observed report preserved, stopping')
  print('DONE',d['id'],[(r['run'],r['status']) for r in current],flush=True)
  rows=new
  if a.phase=='final' and sum(r['status']=='FAIL' for r in rows)>PLAN['baseline_fail_case_limits'][a.platform]:
   sys.exit('RELEASE_CRITERION_FAILED: failure count exceeds rc.7 platform limit; stop without reruns')
 print('BATCH COMPLETE',a.phase,a.platform,'verdicts',len(rows),'remaining scenarios',max(0,len(selected)-a.max_cases),flush=True)
