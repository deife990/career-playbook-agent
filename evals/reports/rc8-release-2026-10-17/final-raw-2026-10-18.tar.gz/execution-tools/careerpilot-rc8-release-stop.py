"""Read-only release-evidence audit; no provider calls and no verdict rewriting."""
import hashlib
import json
import tarfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from scripts.run_model_evals import fingerprint, suite_fingerprint, grade
from scripts.eval_protocol import protocol, protocol_fingerprint, expected_runs, judge_platform
from scripts.variant_eval_lock import content_manifest
import yaml

root = Path.cwd()
base = root / 'work/review-v2/rc8-release-2026-10-17'
out = root / 'evals/reports/rc8-release-2026-10-17'
plan = json.loads((root / 'evals/reports/rc8-release-plan-2026-10-17.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
config = protocol()
assert suite_fingerprint(sorted((root / 'evals/scenarios').glob('*.yaml'))) == plan['c_suite_fingerprint']
assert protocol_fingerprint(config) == plan['c_protocol_fingerprint']
assert sha(root / 'scripts/run_model_evals.py') == plan['frozen_engine_sha256']
assert sha(root / 'docs/rc8-release-policy-2026-10-17.md') == plan['policy_sha256']
hold, _ = content_manifest('final')
assert hold['content_fingerprint'] == plan['holdout_content_fingerprint']
reports, stats, metadata_errors, failures = {}, {}, [], []
preserved_checkpoints = 0
for host in ['chatgpt', 'claude']:
    pkg = base / 'packages' / host
    assert fingerprint(pkg) == plan['packages'][host]['package_fingerprint']
    p = base / 'final' / (host + '.json')
    report = json.loads(p.read_text())
    assert report['package_fingerprint'] == fingerprint(pkg)
    assert report['suite_fingerprint'] == plan['c_suite_fingerprint']
    assert report['protocol'] == config
    assert report['protocol_fingerprint'] == protocol_fingerprint(config)
    rows = report['cases']
    keys = [(r['id'], r['run']) for r in rows]
    assert len(keys) == len(set(keys)) and set(keys) <= expected_runs(config)
    by_key = {(r['id'], r['run']): r for r in rows}
    for snapshot in (base / 'final').glob('checkpoint-' + host + '-*.json'):
        for old in json.loads(snapshot.read_text())['cases']:
            assert by_key[(old['id'], old['run'])] == old
        preserved_checkpoints += 1
    valid = []
    for row in rows:
        assert row['status'] in ['PASS', 'FAIL']
        assert not row.get('prior_attempts')
        case = yaml.safe_load((root / 'evals/scenarios' / (row['id'] + '.yaml')).read_text())
        tier = next(d for d in config['scenarios'] if d['id'] == row['id'])
        assert row['judge_platform'] == judge_platform(host, tier)
        assertions = [a for a in row['assertions'] if a['id'] != 'deterministic-roundtrip']
        assert grade(case['assertions'], json.dumps({'assertions': assertions}), row['transcript']) == assertions
        assert row['status'] == ('PASS' if all(a['pass'] for a in row['assertions']) else 'FAIL')
        for rel, digest in row['loaded_files'].items():
            assert sha(pkg / rel) == digest
        expected_subject = 'gpt-5.6-sol' if host == 'chatgpt' else 'claude-sonnet-4-6'
        expected_judge = 'gpt-5.6-sol' if row['judge_platform'] == 'chatgpt' else 'claude-sonnet-4-6'
        problems = []
        if set(row['model_ids']) != {expected_subject}:
            problems.append('Subject model identity unavailable or different')
        if row['judge_model'] != expected_judge:
            problems.append('Judge model identity unavailable or different')
        if problems:
            metadata_errors.append({'platform': host, 'id': row['id'], 'run': row['run'],
                                    'observed_status': row['status'], 'audit_status': 'ERROR',
                                    'problems': problems, 'model_ids': row['model_ids'],
                                    'judge_model': row['judge_model'], 'attempt_path': row['attempt_path']})
        else:
            valid.append(row)
        if row['status'] == 'FAIL':
            failures.append({'platform': host, 'id': row['id'], 'run': row['run'],
                             'assertions': [a for a in row['assertions'] if not a['pass']]})
    baseline = json.loads((root / f'evals/reports/{host}-review-v2-baseline-complete-2026-10-16.json').read_text())
    assert baseline['suite_fingerprint'] == plan['c_suite_fingerprint']
    assert baseline['protocol_fingerprint'] == plan['c_protocol_fingerprint']
    assert fingerprint(root / 'work/review-v2/baseline/packages' / host) == baseline['package_fingerprint']
    previous = {(r['id'], a['id']) for r in baseline['cases'] for a in r.get('assertions', []) if not a['pass']}
    for failure in [f for f in failures if f['platform'] == host]:
        failure['failed_assertion_keys_already_in_own_baseline'] = all((failure['id'], a['id']) in previous for a in failure['assertions'])
    stats[host] = {'planned': 130, 'observed_rows': len(rows), 'valid_verdicts': len(valid),
                   'valid_pass': sum(r['status'] == 'PASS' for r in valid),
                   'valid_fail': sum(r['status'] == 'FAIL' for r in valid),
                   'quarantined_metadata_error': len(rows) - len(valid), 'unstarted': 130 - len(rows),
                   'rc7_baseline_fail': sum(r['status'] == 'FAIL' for r in baseline['cases']),
                   'tiers': {tier: dict(Counter(r['status'] for r in valid if r['tier'] == tier))
                             for tier in ['critical', 'standard']}}
    reports[host] = report

assert len(metadata_errors) == 1
problem = metadata_errors[0]
assert (problem['platform'], problem['id'], problem['run']) == ('claude', 'context-model-roundtrip', 1)
attempt = Path(problem['attempt_path'])
raw = json.loads((attempt / 'turn-1.stdout.txt').read_text())
assert raw['modelUsage'] == {} and raw['is_error'] is False
assert all(raw['usage'][k] == 0 for k in ['input_tokens', 'output_tokens', 'cache_read_input_tokens', 'cache_creation_input_tokens'])
assert not (attempt / 'turn-1.stderr.txt').read_text()
assert all((base / 'final' / 'runs' / 'claude' / 'context-model-roundtrip' / f'run-{n}' / 'attempt-1' / 'transcript.json').is_file() for n in [1, 2, 3])
raw_files = sorted(p for p in (base / 'final').rglob('*') if p.is_file())
manifest = {str(p.relative_to(base)): sha(p) for p in raw_files}
archive = out / 'final-raw-2026-10-18.tar.gz'
manifest_path = out / 'final-raw-manifest-2026-10-18.json'
audit_path = out / 'final-interruption-2026-10-18.json'
assert not any(p.exists() for p in [archive, manifest_path, audit_path])
with tarfile.open(archive, 'x:gz') as tar:
    for p in raw_files:
        tar.add(p, arcname=p.relative_to(base), recursive=False)
    for name in ['careerpilot-rc8-release-batch.py', 'careerpilot-rc8-release-stop.py']:
        tar.add(Path('/private/tmp') / name, arcname='execution-tools/' + name, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    for rel, digest in manifest.items():
        assert hashlib.sha256(tar.extractfile(rel).read()).hexdigest() == digest
assert manifest == {str(p.relative_to(base)): sha(p) for p in raw_files}
with manifest_path.open('x') as f:
    f.write(json.dumps({'sha256': manifest, 'raw_files': len(manifest)}, ensure_ascii=False, indent=2) + '\n')
audit = {'timestamp': datetime.now(timezone.utc).isoformat(), 'status': 'INCOMPLETE_METADATA_ERROR',
         'release_criteria_met': False, 'release_criteria_outcome': 'NOT_ESTABLISHED',
         'reason': 'One automatic PASS lacks actual subject model provenance; no source log identifies it. Stop under the approved unresolved-error condition. Do not infer identity, rewrite the verdict, or regenerate the subject.',
         'summary': stats, 'metadata_errors': metadata_errors, 'observed_failure_reviews': failures,
         'metadata_error_classification': 'Provider/CLI response metadata absence; not a behavioral FAIL, quota/network diagnosis, or demonstrated frozen-harness regression. The engine preserves unknown provenance; audit excludes the unqualified PASS.',
         'provider_metadata': {k: raw[k] for k in ['is_error', 'duration_ms', 'duration_api_ms', 'num_turns', 'usage', 'modelUsage']},
         'failure_type_review': 'concise run 2: unsupported systematic/data-driven quality in positioning; actual scope inflation already observed in rc.7 C. No new failed assertion key among completed rows; the unfinished suite cannot establish no new failure type overall.',
         'checks': {'suite_protocol_packages_policy_frozen': True, 'loaded_context_hashes': True,
                    'assertion_quotes_and_verdicts': True, 'previous_checkpoint_snapshots_preserved': preserved_checkpoints,
                    'raw_archive_roundtrip_sha256': True, 'raw_sources_unchanged': True,
                    'completed_verdict_reruns': 0, 'old_development_evd07_retry': False,
                    'holdout_model_calls': 0, 'd_or_f_change': False, 'version_bump': False},
         'usage_at_stop': {'codex_five_hour_used_percent': 40, 'codex_weekly_used_percent': 72,
                           'ordinary_usage_allowed': True, 'quota_exhaustion': False,
                           'additional_payment_or_reset_credit': False},
         'raw_archive': str(archive.relative_to(root)), 'raw_archive_sha256': sha(archive),
         'raw_manifest': str(manifest_path.relative_to(root)), 'raw_file_count': len(manifest),
         'reports': reports}
with audit_path.open('x') as f:
    f.write(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'audit': str(audit_path.relative_to(root)), 'summary': stats, 'raw_file_count': len(manifest),
                  'archive_sha256': sha(archive), 'preservation_checks': audit['checks']}, ensure_ascii=False, indent=2))
